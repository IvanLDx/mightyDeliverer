function cambioFase() {

// Cambia de fase positiva á mesma negativa (1 = -1)
	if(pj.intersects(escaleiraDS) && fase > 0) {fase-=fase*2;}
	if(pj.intersects(escaleiraUS) && fase > 0) {fase-=fase*2+0.5;}

	
	
	
	
	

//De 0 a 1
	faseMov(0, 0.1, 0.2, "esq", -pj.spd, -pj.spd);
	if(fase==0.2) {
		resetMap(
			5, 4, 		//pj
			0, 0, 0, 1, //US
			7, 4, 1, 3, //DS
			5, 5, 0.8, 1,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			5, 8, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map01, 11, 1//setWorld
		);
	}

//De 1 a 2
	faseMov(-1, -1.1, -1.2, "der", pj.spd, pj.spd);
	if(fase==-1.2) {
		resetMap(
			9, 4, 		//pj
			8, 4, 1, 1, //US
			8,13, 1, 2, //DS
			6, 7, 0.8, 2,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			6, 9, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map02, 17, 2//setWorld
		);
	}
//De 2 a 1
	faseMov(-2.5, -2.6, -2.7, "esq", -pj.spd, -pj.spd);
	if(fase==-2.7) {
		resetMap(
			6, 4, 		//pj
			0, 0, 0, 1, //US
			7, 4, 1, 3, //DS
			5, 5, 0.8, 1,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			5, 8, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map01, 11, 1//setWorld
		);
	}
//De 2 a 3
	faseMov(-2, -2.1, -2.2, "esq", -pj.spd, pj.spd);
	if(fase==-2.2) {
		resetMap(
			8, 13, 		//pj
			9, 13, 1, 0, //US
			11, 13, 1, 2, //DS
			5, 6, 0.8, 3,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			6, 11, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map03, 17, 3//setWorld
		);
	}
//De 3 a 2
	faseMov(-3.5, -3.6, -3.7, "der", pj.spd, -pj.spd);
	if(fase==-3.7) {
		resetMap(
			9, 13, 		//pj
			8, 4, 1, 1, //US
			8,13, 1, 2, //DS
			6, 7, 0.8, 2,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			6, 9, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map02, 17, 2//setWorld
		);
	}
//De 3 a 4
	faseMov(-3, -3.1, -3.2, "esq", -pj.spd, pj.spd);
	if(fase==-3.2) {
		resetMap(
			12, 18, 		//pj
			13, 18, 1, 0, //US
			13, 4, 1, 3, //DS
			10, 17, 0.8, 4,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			5, 4, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map04, 18, 4//setWorld
		);
	}
//De 4 a 3
	faseMov(-4.5, -4.6, -4.7, "der", pj.spd, -pj.spd);
	if(fase==-4.7) {
		resetMap(
			12, 13, 		//pj
			9, 13, 1, 0, //US
			11, 13, 1, 2, //DS
			5, 6, 0.8, 3,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			6, 11, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map03, 17, 3//setWorld
		);
	}
//De 4 a 5
	faseMov(-4, -4.1, -4.2, "der", pj.spd, pj.spd);
	if(fase==-4.2) {
		resetMap(
			12, 19, 		//pj
			11, 19, 1, 1, //US
			9, 6, 1, 3, //DS
			5, 17, 0.8, 5,  //caixa1
			6, 14, 0.8, 5,  //caixa2
			0, 1, 0, 0,  //caixa3
			11, 15, 1,      //buraco1
			4, 6, 1,     //buraco2
			0, 0, 0,     //buraco3
			7, 14, 1,		//portal1
			5, 12, 1,		//portal2
			0, 0, 0,		//portal3
			map05, 18, 5//setWorld
		);
	}
//De 5 a 4
	faseMov(-5.5, -5.6, -5.7, "esq", -pj.spd, -pj.spd);
	if(fase==-5.7) {
		resetMap(
			12, 4, 		//pj
			13, 18, 1, 0, //US
			13, 4, 1, 3, //DS
			10, 17, 0.8, 4,  //caixa1
			1, 0, 0, 0,  //caixa2
			0, 1, 0, 0,  //caixa3
			5, 4, 1,      //buraco1
			0, 0, 0,      //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map04, 18, 4//setWorld
		);
	}
//De 5 a 6
	faseMov(-5, -5.1, -5.2, "der", pj.spd, pj.spd);
	if(fase==-5.2) {
		resetMap(
			11, 6, 		//pj
			10, 6, 1, 1, //US
			7, 10, 1, 2, //DS
			13, 10, 0.8, 6,  //caixa1
			5, 7, 0.8, 6,  //caixa2
			0, 1, 0, 0,  //caixa3
			7, 8, 1,      //buraco1
			4, 3, 1,     //buraco2
			0, 0, 0,     //buraco3
			12, 8, 1,		//portal1
			11, 9, 1,		//portal2
			0, 0, 0,		//portal3
			map06, 19, 6//setWorld
		);
	}
//De 6 a 5
	faseMov(-6.5, -6.6, -6.7, "esq", -pj.spd, -pj.spd);
	if(fase==-6.7) {
		resetMap(
			8, 6, 		//pj
			11, 19, 1, 1, //US
			9, 6, 1, 3, //DS
			5, 17, 0.8, 5,  //caixa1
			6, 14, 0.8, 5,  //caixa2
			0, 1, 0, 0,  //caixa3
			11, 15, 1,      //buraco1
			4, 6, 1,     //buraco2
			0, 0, 0,     //buraco3
			7, 14, 1,		//portal1
			5, 12, 1,		//portal2
			0, 0, 0,		//portal3
			map05, 18, 5//setWorld
		);
	}
//De 6 a 7
	faseMov(-6, -6.1, -6.2, "esq", -pj.spd, pj.spd);
	if(fase==-6.2) {
		resetMap(
			7, 17, 		//pj
			8, 17, 1, 0, //US
			10, 7, 1, 2, //DS
			11, 16, 0.8, 7,  //caixa1
			5, 6, 0.8, 7,  //caixa2
			5, 6, 0.8, 0,  //caixa3
			12, 4, 1,      //buraco1
			13, 4, 1,     //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map07, 18, 7//setWorld
		);
	}

//De 7 a 6
	faseMov(-7.5, -7.6, -7.7, "der", pj.spd, -pj.spd);
	if(fase==-7.7) {
		resetMap(
			8, 10, 		//pj
			10, 6, 1, 1, //US
			7, 10, 1, 2, //DS
			13, 10, 0.8, 6,  //caixa1
			5, 7, 0.8, 6,  //caixa2
			0, 1, 0, 0,  //caixa3
			7, 8, 1,      //buraco1
			4, 3, 1,     //buraco2
			0, 0, 0,     //buraco3
			12, 8, 1,		//portal1
			11, 9, 1,		//portal2
			0, 0, 0,		//portal3
			map06, 19, 6//setWorld
		);
	}
//De 7 a 8
	faseMov(-7, -7.1, -7.2, "esq", -pj.spd, pj.spd);
	if(fase==-7.2) {
		resetMap(
			5, 18, 		//pj
			6, 18, 1, 0, //US
			4, 4, 1, 2, //DS
			6, 20, 0.8, 8,  //caixa1
			7, 16, 0.8, 8,  //caixa2
			5, 8, 0.8, 0,  //caixa3
			8, 9, 1,      //buraco1
			13, 6, 1,     //buraco2
			0, 0, 0,     //buraco3
			8, 15, 1,		//portal1
			9, 16, 1,		//portal2
			0, 0, 0,		//portal3
			map08, 18, 8//setWorld
		);
	}
//De 8 a 7
	faseMov(-8.5, -8.6, -8.7, "der", pj.spd, -pj.spd);
	if(fase==-8.7) {
		resetMap(
			11, 7, 		//pj
			8, 17, 1, 0, //US
			10, 7, 1, 2, //DS
			11, 16, 0.8, 7,  //caixa1
			5, 6, 0.8, 7,  //caixa2
			5, 6, 0.8, 0,  //caixa3
			12, 4, 1,      //buraco1
			13, 4, 1,     //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map07, 18, 7//setWorld
		);
	}
//De 8 a 9
	faseMov(-8, -8.1, -8.2, "esq", -pj.spd, pj.spd);
	if(fase==-8.2) {
		resetMap(
			5, 13, 		//pj
			6, 13, 1, 0, //US
			10, 17, 1, 3, //DS
			12, 7, 0.8, 9,  //caixa1
			8, 8, 0.8, 9,  //caixa2
			5, 8, 0.8, 9,  //caixa3
			8, 19, 1,      //buraco1
			8, 20, 1,     //buraco2
			7, 20, 1,     //buraco3
			8, 18, 1,		//portal1
			9, 20, 1,		//portal2
			7, 19, 1,		//portal3
			map09, 18, 9//setWorld
		);
	}
//De 9 a 8
	faseMov(-9.5, -9.6, -9.7, "der", pj.spd, -pj.spd);
	if(fase==-9.7) {
		resetMap(
			5, 4, 		//pj
			6, 18, 1, 0, //US
			4, 4, 1, 2, //DS
			6, 20, 0.8, 8,  //caixa1
			7, 16, 0.8, 8,  //caixa2
			5, 8, 0.8, 0,  //caixa3
			8, 9, 1,      //buraco1
			13, 6, 1,     //buraco2
			0, 0, 0,     //buraco3
			8, 15, 1,		//portal1
			9, 16, 1,		//portal2
			0, 0, 0,		//portal3
			map08, 18, 8//setWorld
		);
	}

//De 9 a 10
	faseMov(-9, -9.1, -9.2, "der", pj.spd, pj.spd);
	if(fase==-9.2) {
		resetMap(
			13, 17, 		//pj
			12, 17, 1, 1, //US
			4, 4, 1, 2, //DS
			7, 20, 0.8, 10,  //caixa1
			6, 20, 0.8, 10,  //caixa2
			5, 20, 0.8, 10,  //caixa3
			10, 4, 1,      //buraco1
			12, 15, 1,     //buraco2
			8, 5, 1,     //buraco3
			12, 6, 1,		//portal1
			10, 15, 1,		//portal2
			7, 5, 1,		//portal3
			map10, 18, 10//setWorld
		);
	}

//De 10 a 9
	faseMov(-10.5, -10.6, -10.7, "esq", -pj.spd, -pj.spd);
	if(fase==-10.7) {
		resetMap(
			9, 17, 		//pj
			6, 13, 1, 0, //US
			10, 17, 1, 3, //DS
			12, 7, 0.8, 9,  //caixa1
			8, 8, 0.8, 9,  //caixa2
			5, 8, 0.8, 9,  //caixa3
			8, 19, 1,      //buraco1
			8, 20, 1,     //buraco2
			7, 20, 1,     //buraco3
			8, 18, 1,		//portal1
			9, 20, 1,		//portal2
			7, 19, 1,		//portal3
			map09, 18, 9//setWorld
		);
	}

//De 10 a 11
	faseMov(-10, -10.1, -10.2, "esq", -pj.spd, pj.spd);
	if(fase==-10.2) {
		resetMap(
			5, 4, 		//pj
			6, 4, 1, 0, //US
			5, 17, 1, 2, //DS
			11, 5, 0.8, 11,  //caixa1
			12, 16, 0.8, 11,  //caixa2
			10, 6, 0.8, 11,  //caixa3
			11, 10, 1,      //buraco1
			12, 9, 1,     //buraco2
			12, 11, 1,     //buraco3
			9, 10, 1,		//portal1
			12, 7, 1,		//portal2
			12, 13, 1,		//portal3
			map11, 18, 11//setWorld
		);
	}

//De 11 a 10
	faseMov(-11.5, -11.6, -11.7, "der", pj.spd, -pj.spd);
	if(fase==-11.7) {
		resetMap(
			5, 4, 		//pj
			12, 17, 1, 1, //US
			4, 4, 1, 2, //DS
			7, 20, 0.8, 10,  //caixa1
			6, 20, 0.8, 10,  //caixa2
			5, 20, 0.8, 10,  //caixa3
			10, 4, 1,      //buraco1
			12, 15, 1,     //buraco2
			8, 5, 1,     //buraco3
			12, 6, 1,		//portal1
			10, 15, 1,		//portal2
			7, 5, 1,		//portal3
			map10, 18, 10//setWorld
		);
	}

//De 11 a 12
	faseMov(-11, -11.1, -11.2, "esq", -pj.spd, pj.spd);
	if(fase==-11.2) {
		resetMap(
			4, 12, 		//pj
			5, 12, 1, 0, //US
			0, 2, 0, 0, //DS
			10, 7, 0.8, 12,  //caixa1
			0, 1, 0, 0,  //caixa2
			0, 2, 0, 0,  //caixa3
			10, 13, 1,      //buraco1
			0, 0, 0,     //buraco2
			0, 0, 0,     //buraco3
			0, 0, 0,		//portal1
			0, 0, 0,		//portal2
			0, 0, 0,		//portal3
			map12, 18, 12//setWorld
		);
	}

//De 12 a 11
	faseMov(-12.5, -12.6, -12.7, "der", pj.spd, -pj.spd);
	if(fase==-12.7) {
		resetMap(
			6, 17, 		//pj
			6, 4, 1, 0, //US
			5, 17, 1, 2, //DS
			11, 5, 0.8, 11,  //caixa1
			12, 16, 0.8, 11,  //caixa2
			10, 6, 0.8, 11,  //caixa3
			11, 10, 1,      //buraco1
			12, 9, 1,     //buraco2
			12, 11, 1,     //buraco3
			9, 10, 1,		//portal1
			12, 7, 1,		//portal2
			12, 13, 1,		//portal3
			map11, 18, 11//setWorld
		);
	}

}