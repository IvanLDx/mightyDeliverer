// INTRO -------------------------------------------------------------------------
var intro1 = new rect(0,0,420,108);
var intro2 = new rect(0,0,304,76);
var introImg = new Image; introImg.src = "img/logoRESgamesFrames.png";
var tituloImg = new Image; tituloImg.src = "img/titulo.png";
var contadorIntro = 0, velIntro = 0;
var glitch = new Audio(); glitch.src = "audio/glitch.mp3";
glitch.volume = 0.6;
function introA() {
	intro1.x = (tamanhoWindowW-intro1.width)/2;
	intro1.y = (tamanhoWindowH-intro1.height)/2;

	glitch.play();

	/*if(contadorIntro < 25 && direciónIntro == true) {
		contadorIntro += 2;
	} else if (contadorIntro < 34 && direciónIntro == true) {
		contadorIntro++;
	} else if (contadorIntro == 34 && direciónIntro == true) {
		direciónIntro = false;
	} else if (contadorIntro >= 33 && direciónIntro == false) {
		contadorIntro = 32;
	} else if (contadorIntro == 32 && direciónIntro == false) {
		contadorIntro = 38; direciónIntro = true;
	}*/

	if(contadorIntro < 100) {
		contadorIntro++;
	}
		
	velIntro = Math.floor(contadorIntro/4);

	cx.fillStyle="#222";
	cx.fillRect(0,0,cv.width,cv.height);
	if(contadorIntro <= 44) {
		intro1.fillAnime(introImg,cx,cam,0,velIntro*intro1.height,intro1.width,intro1.height);
	} else {
		intro1.fillAnime(introImg,cx,cam,0,11*intro1.height,intro1.width,intro1.height);
	}



	if(contadorIntro < 80) {
		setTimeout(function(){introA();}, timing);
	} else {
		contadorIntro = 0;
		fase = 1;
		act();
		introB();
	}
}